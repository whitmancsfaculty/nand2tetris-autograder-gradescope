"""
hjcError.py -- Error exceptions for Hack Jack compiler
Solution provided by Nand2Tetris authors, licensed for educational purposes
"""

class HjcError(Exception):
    pass
    
