apt-get -y install default-jre
