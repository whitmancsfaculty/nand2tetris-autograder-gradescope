#!/bin/bash

# Get circuit info
project=$1
circuit=$2
maxscore=$3

echo $circuit $maxscore

# Locate directories and files
base=$(pwd)
if [ "$VENDOR" == "apple" ]; then
    source="$base"
else
    source="$base/source"
fi
tool="$source/nand2tetris/tools/HardwareSimulator.sh"
submission="$base/submission"
hdlfile="$submission/$circuit.hdl"
tstfile="$submission/$circuit.tst" 
cmpfile="$submission/$circuit.cmp" 
outfile="$submission/$circuit.out"
stdoutfile="$submission/$circuit.stdout"
gradefile="$base/results/$circuit.results.json"

## Find the maximum score by counting the number of test results in the
## comparison file.  The first line is a header.
#maxscore=`wc -l < $cmpfile`
#(( maxscore-- ))

if [ ! -f "$hdlfile" ]; then
    # File not found
    score=0.0
    message="$circuit.hdl not submitted"
else
    # Run tests, redirecting stderr and stdout
	command="$tool $tstfile &> $stdoutfile"
	eval $command 

	if [ ! -s $stdoutfile ]; then
        # The result file is empty.
	    score=0
        message="The test did not run. Contact your instructor for assistance."
    else
	    # If the result file is not empty, parse the results.
	    IFS=$'\r\n' GLOBIGNORE='*' command eval 'lines=($(cat $stdoutfile))'
	    result="${lines[0]}"
        echo $result
	    if [[ "$result" == *success* ]]; then
	        score=$maxscore
	        message="All tests pass!"    
	    elif [[ "$result" == *failure* ]]; then
            #passed=${result#"Comparison failure at line "}
            #((passed -=2 )) # First line is header; last line is mismatch
            score=0
            message="First $score out of $maxscore tests pass."
        else
            score=0
            message="No tests pass. $result"
	    fi    
	fi
fi
cat > $gradefile <<EOF
	{
	    "score": $score,
	    "max_score": $maxscore,
	    "number": "$circuit",
	    "output": "$message"
	},
EOF
