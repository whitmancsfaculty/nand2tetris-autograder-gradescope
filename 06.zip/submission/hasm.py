#!/usr/bin/python3
# Some text copyright (C) 2011 Mark Armbrust.  
# Permission granted for educational use.
# Skeletonized March 2016 by Janet Davis
# Refactored May 19, 2016 by Janet Davis
# Refactored February 2018 by John Stratton
# Refactored January 2019 by Janet Davis

"""
hasm.py -- Hack computer assembler

See "The Elements of Computing Systems", by Noam Nisan and Shimon Schocken
"""

from hasmUtils import *
from sys import argv
import re

def initSymbolTable():
    """
    Returns a Python dictionary mapping strings (symbol names) to 
    integers (address refered to by that symbol), initialized with 
    all of the Hack assembly built-in symbols.
    """
    predefined_symbols = {
            'SP': 0,
            'LCL': 1,
            'ARG': 2,
            'THIS': 3,
            'THAT': 4,
            'R0': 0,
            'R1': 1,
            'R2': 2,
            'R3': 3,
            'R4': 4,
            'R5': 5,
            'R6': 6,
            'R7': 7,
            'R8': 8,
            'R9': 9,
            'R10': 10,
            'R11': 11,
            'R12': 12,
            'R13': 13,
            'R14': 14,
            'R15': 15,
            'SCREEN': 0x4000,
            'KBD': 0x6000
            }
    return predefined_symbols

def readASMFile(input_filename):
    """
    Reads the list of assembly commands from input, removing comments.
    Returns a list of non-empty, non-comment lines.  Each should represent 
    a single command, either an A_COMMAND, C_COMMAND, or L_COMMAND
    """
    try:
        inFile = open(input_filename, 'r')
    except:
        FatalError('Could not open source file "'+input_filename+'"')

    rawline = inFile.readline()
    list_of_lines = []

    while rawline != '':
        # Parse the line. Start by removing whitespace
        line = rawline.strip()

        # Then deal with comments
        comment_start = line.find("//")
        if comment_start >= 0:
            # Keep the part of the line before the comment
            line = line[:comment_start]

        # If the entire line is a comment or empty, 
        # do nothing and skip to the next line
        if line != '':
            # Add the non-empty preprocessed line to the list
            list_of_lines.append( line )
        rawline = inFile.readline()

    inFile.close()
    return list_of_lines

def command_type(command):
    """
    Returns one of the defined constants A_COMMAND, C_COMMAND, or L_COMMAND to 
    identify the type of command represented by the parameter string.
    If the command is none of these types, throw a FatalError exception
    """
    # TODO phase 1: Categorize A_COMMAND and C_COMMAND
    # TODO phase 2: Categorize L_COMMAND
    pass
    if command[0]=="@":
        return A_COMMAND
    else:
        return C_COMMAND


def first_pass(command_list, symbol_table):
    # TODO phase 2: Add labels to symbol table
    pass

def emit_C_command(command, output_file):
    # TODO phase 1: write the binary machine code for a C command (as a string)

    # Note that the codeTranslator object has methods 
    # dest(string), comp(string) and jump(string) to translate assembly 
    # mnemonics of teach type into strings of 0 and 1.
    codeTranslator = Code()
    pass

    dest, comp = command.split("=")
    comp = codeTranslator.comp(comp)
    dest = codeTranslator.dest(dest)
    output_file.write("1110{}{}000".format(comp,dest))


def emit_A_command(command, symbol_table, output_file):
    # TODO phase 1: write the binary machine code for an A command (as a string)
    # TODO phase 2: revise to handle labels as well as integer constants
    pass

    value=int(command[1:], 0)
    output_file.write("0{0:0>15b}\n".format(value))

def second_pass(command_list, symbol_table, output_filename):
    # Open output file
    output_file = open(output_filename, "w");
    if not output_file:
        FatalError("Cannot open output file " + output_filename)

    # Parse input file and emit code
    for command in command_list:
        if command_type(command) == A_COMMAND:
            emit_A_command(command, symbol_table, output_file)
        elif command_type(command) == C_COMMAND:
            emit_C_command(command, output_file)
        #Note that we do not emit label commands

    output_file.close()
   

if __name__ == '__main__':
    # Get input and output filenames
    input_filename = argv[1]
    match = re.match('^(.*)\.asm$', input_filename)
    if not match:
        FatalError(input_filename + " is not an asm file")
    output_filename = match.groups()[0] + ".hack"

    # Create a symbol table with predefined symbols
    symbol_table = initSymbolTable()

    # Read and preprocess the assembly source code into a list of commands
    list_of_commands = readASMFile(input_filename)

    # Assemble the code!
    first_pass(list_of_commands, symbol_table)
    second_pass(list_of_commands, symbol_table, output_filename)

