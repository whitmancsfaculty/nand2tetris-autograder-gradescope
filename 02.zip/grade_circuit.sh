#!/bin/bash

# Get circuit info
project=$1
circuit=$2
maxscore=$3

echo $circuit $maxscore

# Locate directories and files
base=$(pwd)
if [ "$VENDOR" == "apple" ]; then
    source="$base"
else
    source="$base/source"
fi
tool="$source/nand2tetris/tools/HardwareSimulator.sh"
submission="$base/submission"
hdlfile="$submission/$circuit.hdl"
tstfile="$submission/$circuit.tst" 
cmpfile="$submission/$circuit.cmp" 
outfile="$submission/$circuit.out"
stdoutfile="$submission/$circuit.stdout"
gradefile="$base/results/$circuit.results.json"

if [ ! -f $hdlfile             -a ALU-nostat != $circuit -o \
     ! -f $submission/ALU.hdl  -a ALU-nostat == $circuit ]; then
    # Circuit file not found
    score=0
    message="Circuit not submitted"
else 
    # Run tests, redirecting stderr and stdout
    command="$tool $tstfile &> $stdoutfile"
    eval $command 

    if [ ! -s $stdoutfile ]; then
         # The test did not run.
	    score=0
        message="The test did not run. Contact your instructor for assistance."
    else
	    # If the result file is not empty, parse the results.
	    IFS=$'\r\n' GLOBIGNORE='*' command eval 'lines=($(cat $stdoutfile))'
	    result="${lines[0]}"
        echo $result
	    if [[ "$result" == *success* ]]; then
	        score=$maxscore
	        message="All tests pass!"    
	    elif [[ "$result" == *failure* ]]; then
            score=0
            message="First $score out of $maxscore tests pass."
        else
            score=0
            message="$result"
	    fi
    fi
fi

cat > $gradefile <<EOF
	{
	    "score": $score,
	    "max_score": $maxscore,
	    "number": "$circuit",
	    "output": "$message"
	},
EOF
